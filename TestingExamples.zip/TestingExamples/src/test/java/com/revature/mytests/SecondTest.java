package com.revature.mytests;

import org.junit.jupiter.api.Test;

public class SecondTest {
	@Test
	public void thirdTest() {
		System.out.println("This is my third test -- class second test class.");
	}
	@Test
	public void fourthTest() {
		System.out.println("This is my fourth test -- class second test class.");
	}
}
