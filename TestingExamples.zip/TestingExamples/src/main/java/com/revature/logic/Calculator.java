package com.revature.logic;

public class Calculator {

	public int add(int n1, int n2) {
		int result = n1 + n2;
		return result;
	}
	
	public int sub(int n1, int n2) {
		int result = n1 - n2;
		return result;
	}
	
	public int mup(int n1, int n2) {
		int result = n1 * n2;
		return result;
	}
	
	public int div(int n1, int n2) {
		int result = n1 / n2;
		return result;
	}
}
