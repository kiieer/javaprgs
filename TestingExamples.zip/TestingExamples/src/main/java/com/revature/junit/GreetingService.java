package com.revature.junit;

public interface GreetingService {
    String greet(String name);
}