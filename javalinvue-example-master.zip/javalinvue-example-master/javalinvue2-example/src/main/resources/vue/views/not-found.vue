<template id="not-found">
    <app-frame>
        <h1>Page not found (error 404)</h1>
    </app-frame>
</template>
<script>
    Vue.component("not-found", {template: "#not-found"});
</script>
