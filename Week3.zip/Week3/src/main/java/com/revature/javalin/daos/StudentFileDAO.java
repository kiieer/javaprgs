package com.revature.javalin.daos;

import java.util.List;

import com.revature.javalin.entity.Student;

public class StudentFileDAO implements StudentDAO {

	@Override
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		//access the student from FILE
		return null;
	}
	//This class will have methods that perform CRUD operations on Student.
	//Using the Java File Handling API
	
	// CREATE A STUDENT
	
	// READ A STUDENT
	
	// UPDATE A STUDENT
	
	// DELETE A STUDENT
}
