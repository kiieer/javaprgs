package com.revature.javalin.daos;

import java.util.List;

import com.revature.javalin.entity.Student;

public class StudentCollectionDAO implements StudentDAO {

	@Override
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		// Write logic to access the Collection.
		return null;
	}
	//This class will have methods that perform CRUD operations on Student.
	//Using the collection API
	
	// CREATE A STUDENT
		// USE COLLECTION .add METHOD
	
	// READ A STUDENT
		// USE COLLECTION get METHOD
	
	//UPDATE A STUDENT
		//WRITE LOGIC TO UPDATE STUDENT TO COLLECTION
	
	//DELETE A STUDENT
		//USE COLLECTION remove METHOD
}
