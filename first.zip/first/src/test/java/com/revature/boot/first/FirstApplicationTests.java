package com.revature.boot.first;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstApplicationTests {

	@Test
	void contextLoads() {
	}

}
